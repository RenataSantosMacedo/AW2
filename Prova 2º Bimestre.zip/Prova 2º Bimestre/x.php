<!DOCTYPE HTML>
<html lang="pt-br">  
    <head>  
        <meta charset="utf-8">
        <title>Celke - Adicionar Campo</title>
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
        <style>
            .form-group{
                padding: 10px;
            }
        </style>
    </head>
    <body>
        <h1>Adicionar Campo</h1>
        <form method="GET" action="Formulário.php"> 
            <div id="formulario">
                    <input type="text" name="equipamento[]" placeholder="Digite o nome do equipamento">
                    <input type="number" name="consumo[]" placeholder="Digite o consumo em Watts">
                    <input type="number" name="hora[]" placeholder="Digite o tempo">
                    <input type="number" name="dias[]" placeholder="Digite os dias">
                    <button type="button" id="Adicionar"> + </button>
            </div>
        
            <input type="submit" name="enviar" value="Enviar"><br><br>
        
        </form>

        <script>
            //https://api.jquery.com/click/
            $("#Adicionar").click(function () {
				//https://api.jquery.com/append/
                $("#formulario").append('<div id="formulario"><input type="text" name="equipamento[]" placeholder="Digite o nome do equipamento"><input type="number" name="consumo[]" placeholder="Digite o consumo em Watts"><input type="number" name="hora[]" placeholder="Digite o tempo"><input type="number" name="dias[]" placeholder="Digite os dias"><button type="button" id="Adicionar"> + </button></div>');
            });
        </script>
    </body>
</html>